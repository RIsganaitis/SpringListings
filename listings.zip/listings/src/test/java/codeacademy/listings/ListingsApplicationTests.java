package codeacademy.listings;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ListingsApplicationTests {

	@Test
	void contextLoads() {
	}

}
